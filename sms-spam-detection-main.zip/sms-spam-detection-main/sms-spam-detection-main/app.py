import shap
import numpy as np
import nltk
import pandas as pd
import streamlit as st
import pickle
import string
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer

# Download required resources
nltk.download('punkt')
nltk.download('stopwords')

# Preprocessing function
ps = PorterStemmer()
def transform_text(text):
    text = text.lower()
    text = nltk.word_tokenize(text)

    y = []
    for i in text:
        if i.isalnum():
            y.append(i)

    text = y[:]
    y.clear()

    for i in text:
        if i not in stopwords.words('english') and i not in string.punctuation:
            y.append(i)

    text = y[:]
    y.clear()

    for i in text:
        y.append(ps.stem(i))

    return " ".join(y)

# Load model and vectorizer
tk = pickle.load(open("vectorizer.pkl", 'rb'))
model = pickle.load(open("model.pkl", 'rb'))

# SHAP setup
background = tk.transform([""]).toarray()
explainer = shap.KernelExplainer(model.predict_proba, background)

# Streamlit app
st.title("📩 SMS Spam Detection with Explanation")
st.write("*Made with ❤️ by Shrudex 👨🏻‍💻*")

# --- SINGLE SMS INPUT ---
input_sms = st.text_input("Enter a single SMS for prediction:")

if st.button("Predict"):
    transformed_sms = transform_text(input_sms)
    vector_input = tk.transform([transformed_sms])
    result = model.predict(vector_input)[0]
    st.header("Spam" if result == 1 else "Not Spam")

    # SHAP explanation
    shap_values = explainer.shap_values(vector_input.toarray())
    feature_names = tk.get_feature_names_out()

    if isinstance(shap_values, list):
        shap_scores = shap_values[1][0]
    else:
        shap_scores = shap_values[0]

    non_zero_indices = vector_input.nonzero()[1]
    word_scores = [(feature_names[i], shap_scores[i]) for i in non_zero_indices]

    # ✅ FIX: use np.sum to flatten array before sorting
    top_words = sorted(word_scores, key=lambda x: abs(float(np.sum(x[1]))), reverse=True)[:10]

    st.subheader("Top contributing words:")
    for word, score in top_words:
        color = "red" if np.sum(score) > 0 else "green"
        st.markdown(f"<span style='color:{color}'>{word}</span>: {float(np.sum(score)):.4f}", unsafe_allow_html=True)

# --- BULK PREDICTION VIA CSV ---
st.markdown("---")
st.subheader("📤 Upload CSV for Bulk Predictions")

uploaded_file = st.file_uploader("Upload a CSV file with a column named `message`", type="csv")

if uploaded_file is not None:
    df = pd.read_csv(uploaded_file)

    if "message" not in df.columns:
        st.error("The CSV must have a column named 'message'.")
    else:
        results = []

        for msg in df["message"]:
            transformed = transform_text(msg)
            vector = tk.transform([transformed])
            prediction = model.predict(vector)[0]
            label = "Spam" if prediction == 1 else "Not Spam"

            # SHAP explanation
            shap_values = explainer.shap_values(vector.toarray())
            feature_names = tk.get_feature_names_out()

            if isinstance(shap_values, list):
                scores = shap_values[1][0]
            else:
                scores = shap_values[0]

            nonzero_idx = vector.nonzero()[1]
            word_scores = [(feature_names[i], scores[i]) for i in nonzero_idx]

            # ✅ FIX: safe sum for SHAP arrays
            top_words = sorted(word_scores, key=lambda x: abs(float(np.sum(x[1]))), reverse=True)[:5]
            explanation = ", ".join([f"{w} ({'+' if np.sum(s) > 0 else ''}{float(np.sum(s)):.2f})" for w, s in top_words])

            results.append({
                "Message": msg,
                "Prediction": label,
                "Explanation (Top Words)": explanation
            })

        result_df = pd.DataFrame(results)
        st.dataframe(result_df)
