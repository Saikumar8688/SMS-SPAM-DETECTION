import pandas as pd
import numpy as np
import string
import nltk
import pickle
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer

# Download required NLTK data
nltk.download('punkt')
nltk.download('stopwords')

# Initialize stemmer
ps = PorterStemmer()

# Text preprocessing function
def transform_text(text):
    text = text.lower()
    text = nltk.word_tokenize(text)

    y = []
    for i in text:
        if i.isalnum():
            y.append(i)

    text = y[:]
    y.clear()

    for i in text:
        if i not in stopwords.words('english') and i not in string.punctuation:
            y.append(i)

    text = y[:]
    y.clear()

    for i in text:
        y.append(ps.stem(i))

    return " ".join(y)

# -------------------------------------
# ✅ Load dataset and preprocess
# -------------------------------------
# Load the CSV file (no header row in original file)
df = pd.read_csv("sms-spam.csv", encoding='ISO-8859-1', header=None)

# Rename first two columns
df = df.rename(columns={0: "label", 1: "text"})

# Keep only the necessary columns
df = df[["label", "text"]]

# Convert labels: 'ham' → 0, 'spam' → 1
df["label"] = df["label"].map({"ham": 0, "spam": 1})

# ✅ Drop rows where label became NaN
df = df.dropna(subset=["label"])

# -------------------------------------
# ✅ Preprocess text data
# -------------------------------------
df["transformed_text"] = df["text"].apply(transform_text)

# TF-IDF vectorization
tfidf = TfidfVectorizer(max_features=3000)
X = tfidf.fit_transform(df["transformed_text"]).toarray()
y = df["label"].values

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train the model
model = MultinomialNB()
model.fit(X_train, y_train)

# -------------------------------------
# ✅ Save model and vectorizer
# -------------------------------------
with open("model.pkl", "wb") as f:
    pickle.dump(model, f)

with open("vectorizer.pkl", "wb") as f:
    pickle.dump(tfidf, f)

print("✅ Model and vectorizer saved successfully.")
